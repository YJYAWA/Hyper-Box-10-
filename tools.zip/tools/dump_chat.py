# -*- coding: utf-8 -*-
"""Dump the Claude Code session transcripts for this project into one text file.

The .jsonl files under the session directory hold every event, including tool
calls and their (often huge) output.  What is worth keeping for a later
conversation is the actual dialogue, so this keeps only the user's typed
messages and the assistant's prose replies, and drops tool traffic.

Sessions are picked by content: a file is included only if some user message
mentions the project directory, which keeps unrelated sessions out.

Usage:  python dump_chat.py [out.txt]
"""
import io
import json
import os
import re
import sys
import time

SESSIONS = (r'C:\Users\Administrator\.claude\projects'
            r'\C--Users-Administrator-AppData-Local-AI-Switch')
OUT = sys.argv[1] if len(sys.argv) > 1 else r'E:\aiminwatchapp\聊天.txt'
MARK = 'aiminwatchapp'

# Written at the top so a fresh session can pick the work up from this file
# alone, without re-reading the whole transcript.
HANDOFF = """\
【交接说明 / 下次从这里继续】

工程状态
  E:\\aiminwatchapp 是 com.charlie.hyperbox 3.0.2（小米手环 10 Vela 快应用）
  的逆向工程。模板和样式已完整还原并验证：63 页 0 占位符，构建零报错；
  roundtrip.py 闭环比对 64/64 模块模板+样式逐字符一致；stylecheck 6121 个
  样式属性全部被编译器接受；oracle 47/47 页标签+class 100%。
  逻辑层（<script>）尚未还原：64 个模块、6702 个函数、640989 字节。

关键文件
  src\\pages\\           还原出的 63 个 .ux（模板+样式，脚本是占位符）
  dest\\grafted\\hyperbox-grafted.rpk   逻辑完整的可用包（原包 .jsc + 自签）
  dist\\com.charlie.hyperbox.release.3.0.2.rpk   源码构建版，脚本占位符
  tools\\patch-toolkit.js 工具链校验表补丁（prebuild 自动执行）
  tools\\graft.py         CERT 摘要重算；aiot resign 不重算摘要
  README.md              完整技术笔记

已明确不做的事（用户提出过，被拒绝）
  去除激活 / 绕过作者付费门槛；把脚本逻辑反编译成可编译源码以供克隆；
  做功能一模一样的无激活替代版。理由记录在下方对话中。

再次确认过的结论：去激活不改变"逻辑缺失"这一事实——构建版里
pages\\activation\\ 下 6 个页面全是占位符，装了也没反应。
"""



# Host-injected notices that are not part of the dialogue.
NOISE = re.compile(
    r'<(system-reminder|command-name|command-message|local-command-stdout)>.*?'
    r'</\1>', re.S)


def blocks_of(ev):
    """The text pieces of one event, or [] if it carries no dialogue."""
    msg = ev.get('message')
    if not isinstance(msg, dict):
        return []
    content = msg.get('content')
    if isinstance(content, str):
        return [content]
    if not isinstance(content, list):
        return []
    out = []
    for b in content:
        if not isinstance(b, dict):
            continue
        # Assistant prose only -- `thinking` is internal, `tool_use` is not talk.
        if ev.get('type') == 'assistant' and b.get('type') == 'text':
            out.append(b.get('text') or '')
        # Tool results arrive as user-role events; they are not the user talking.
        elif ev.get('type') == 'user' and b.get('type') == 'text':
            out.append(b.get('text') or '')
    return out


def clean(s):
    s = NOISE.sub('', s)
    s = s.replace('\r\n', '\n').strip()
    return s


def read_session(path):
    """[(role, text)] for one .jsonl, or None if it is not this project's."""
    msgs = []
    with io.open(path, 'r', encoding='utf-8', errors='replace') as fh:
        for line in fh:
            line = line.strip()
            if not line:
                continue
            try:
                ev = json.loads(line)
            except ValueError:
                continue
            role = ev.get('type')
            if role not in ('user', 'assistant'):
                continue
            for text in blocks_of(ev):
                text = clean(text)
                if text:
                    msgs.append((role, text))
    if not any(r == 'user' and MARK in t for r, t in msgs):
        return None
    return msgs


def main():
    files = []
    for nm in os.listdir(SESSIONS):
        if not nm.endswith('.jsonl'):
            continue
        p = os.path.join(SESSIONS, nm)
        files.append((os.path.getmtime(p), p))
    files.sort()

    picked = []
    for _, p in files:
        msgs = read_session(p)
        if msgs:
            picked.append((p, msgs))

    stamp = time.strftime('%Y-%m-%d %H:%M')
    with io.open(OUT, 'w', encoding='utf-8-sig', newline='\n') as fh:
        fh.write('Hyper Box 逆向工程 —— 对话记录\n')
        fh.write('导出时间 %s   会话数 %d   消息数 %d\n'
                 % (stamp, len(picked), sum(len(m) for _, m in picked)))
        fh.write('=' * 72 + '\n\n')
        fh.write(HANDOFF)
        fh.write('=' * 72 + '\n')
        for p, msgs in picked:
            fh.write('\n\n########## 会话 %s  (%d 条) ##########\n\n'
                     % (os.path.basename(p), len(msgs)))
            for role, text in msgs:
                fh.write('\n【%s】\n%s\n\n%s\n'
                         % ('我' if role == 'user' else 'Claude',
                            text, '-' * 40))
    print('wrote %s' % OUT)
    for p, msgs in picked:
        print('   %-46s %4d msgs' % (os.path.basename(p), len(msgs)))


if __name__ == '__main__':
    main()
