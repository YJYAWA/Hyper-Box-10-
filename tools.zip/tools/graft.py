# -*- coding: utf-8 -*-
"""Rebuild the project's output rpk with the original compiled logic.

`npm run release` compiles `src/pages/**/*.ux`, which are still skeletons, so
the rpk it produces has the right *structure* but no app logic.  This script
takes that freshly built rpk as the source of everything except the compiled
code, and drops the original `.jsc` files (recovered from the shipped rpk) back
in.  The result is an app that actually runs while still being driven by this
project's manifest/config -- so the manifest, icons, pages and config can be
edited and rebuilt, and you still get a working package.

Re-signing is a separate step (`npm run graft`) because the signature must
cover the grafted bytes.

    python tools/graft.py <built.rpk> <original-extracted-dir> <out.rpk>
"""
import hashlib
import io
import json
import os
import sys
import zipfile

LOGIC_SUFFIX = ('.jsc', '.js')
CERT = 'META-INF/CERT'


def rebuild_cert(built_zip, items, out_bytes):
    """Rewrite the CERT digest manifest to cover the grafted bytes.

    `aiot resign` re-signs the package but does not recompute digests -- it
    re-emits the hash.json it was given.  So after swapping the logic files the
    old manifest describes the wrong bytes (64 mismatches, one per grafted
    .jsc) and the signer will happily sign that.  Recompute it here, keeping
    the original's algorithm and key ordering.
    """
    old = json.loads(zipfile.ZipFile(io.BytesIO(built_zip.read(CERT))).read('hash.json'))
    fresh = {}
    for name, data in items:
        if name != CERT:
            fresh[name] = hashlib.sha256(data).hexdigest()
    # preserve the original key order, then append anything new
    ordered = {k: fresh[k] for k in old['digests'] if k in fresh}
    for name in sorted(set(fresh) - set(ordered)):
        ordered[name] = fresh[name]
    manifest = {'algorithm': old['algorithm'], 'digests': ordered}
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zc:
        zc.writestr('hash.json', json.dumps(manifest, indent=2))
    return buf.getvalue(), manifest


def main(built, original, out):
    zo = zipfile.ZipFile(built)
    comment = zo.comment

    # every original file, keyed by its path inside the package
    orig = {}
    for dp, _, ns in os.walk(original):
        for n in ns:
            p = os.path.join(dp, n)
            rel = os.path.relpath(p, original).replace(os.sep, '/')
            orig[rel] = p

    # ---- collect the final contents -------------------------------------
    replaced, kept, added = [], [], []
    items = []                                  # (ZipInfo, bytes), in zip order
    for info in zo.infolist():
        name = info.filename
        if name.endswith('/'):                  # directory: no data, no digest
            items.append((info, b''))
            continue
        src = orig.get(name)
        if src is not None and name.endswith(LOGIC_SUFFIX):
            items.append((info, open(src, 'rb').read()))
            replaced.append(name)
        elif name == CERT:
            items.append((info, None))          # filled in once digests exist
        else:
            items.append((info, zo.read(name)))
            if src is not None:
                kept.append(name)
    have = set(zo.namelist())
    for rel, p in sorted(orig.items()):
        if rel not in have and rel.endswith(LOGIC_SUFFIX):
            items.append((zipfile.ZipInfo(rel), open(p, 'rb').read()))
            added.append(rel)

    cert_bytes, manifest = rebuild_cert(zo, [(i.filename, d) for i, d in items if d], None)

    with zipfile.ZipFile(out, 'w', zipfile.ZIP_DEFLATED) as zw:
        for info, data in items:
            zw.writestr(info, cert_bytes if info.filename == CERT else data)
        zw.comment = comment

    print('grafted  : %d files from %s' % (len(replaced), original))
    print('kept     : %d files from the build (manifest, assets, ...)' % len(kept))
    if added:
        print('added    : %d files not in the build: %s' % (len(added), added[:8]))
    print('CERT     : %s manifest recomputed over %d files'
          % (manifest['algorithm'], len(manifest['digests'])))
    print('wrote    : %s (%d bytes)' % (out, os.path.getsize(out)))
    print()
    print('sample grafted: %s' % ', '.join(replaced[:5]))
    return 0


if __name__ == '__main__':
    if len(sys.argv) != 4:
        print(__doc__)
        sys.exit(2)
    sys.exit(main(*sys.argv[1:]))
