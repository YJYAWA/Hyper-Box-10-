// Widen the toolkit's own validation tables to cover what this app uses.
//
// `@aiot-toolkit/compiler` validates every style property and every component
// attribute against tables in
//
//     lib/style/validator.js        (validatorMap)
//     lib/template/validator.js     (the per-tag tables behind tagAttrMap)
//
// and rejects anything absent:
//
//     ERROR: Style name `x` is not supported
//     ERROR: Component `marquee` does not support attribute `x`
//
// The shipped app was built with a toolkit whose tables were wider.  Its own
// compiled modules hold names 1.1.4 lacks -- `letterSpacing` alone appears in 61
// of its 63 pages, and `textOffset` on 8 marquees -- yet the runtime supports
// them, because they are in the released bytecode.  Without this, rebuilding
// that same source is rejected over names the device handles fine.
//
// Nothing 1.1.4 actually checks is loosened: each name added is one the app's
// own compiled modules already carry, mapped to the most permissive entry the
// table's shape allows.  Both edits are idempotent, and the `prebuild`/
// `prerelease` hooks re-apply them after any `npm install`.
//
// Targets the user authorised by name (2026-09-25):
//   node_modules/@aiot-toolkit/compiler/lib/style/validator.js
//   node_modules/@aiot-toolkit/compiler/lib/template/validator.js
const fs = require('fs');
const path = require('path');

const ROOT = path.join(__dirname, '..');

// Style properties.  The compiler's contract is `fn(value) -> {value}`.
const STYLE_NAMES = [
  'letterSpacing',
  'selectedFontSize',
  'selectedBackgroundColor',
  'fontVariationSettings',
  'textStyle',
];

// Component attributes: `tag` -> names to add to that tag's attr table, spelled
// as the source writes them rather than as the compiler keys them (`scroll-x`
// is stored as `scrollX`, so `textOffset` is written `text-offset`).  An empty
// entry imposes no constraint, and adds no default, so nothing is injected into
// elements that do not already carry the attribute.
const TAG_ATTRS = {
  marquee: ['text-offset'],
};

const MARK = '/*patch-toolkit*/';

function load(rel) {
  const p = path.join(ROOT, 'node_modules', '@aiot-toolkit', 'compiler', 'lib', rel);
  if (!fs.existsSync(p)) {
    console.error(`patch-toolkit: ${p} not found -- run npm install first`);
    process.exit(1);
  }
  return { file: p, src: fs.readFileSync(p, 'utf8') };
}

function patchStyles() {
  const { file, src: before } = load('style/validator.js');
  if (before.includes(MARK)) {
    console.log(`patch-toolkit: style names already applied (${STYLE_NAMES.length})`);
    return;
  }
  const at = before.indexOf('validatorMap={');
  if (at < 0) {
    console.error('patch-toolkit: validatorMap not found -- toolkit layout changed');
    process.exit(1);
  }
  const add = MARK + STYLE_NAMES.map(n => `${n}:function(v){return {value:v}},`).join('');
  const head = at + 'validatorMap={'.length;
  fs.writeFileSync(file, before.slice(0, head) + add + before.slice(head));
  console.log(`patch-toolkit: added ${STYLE_NAMES.length} style names`);
  console.log(`  ${STYLE_NAMES.join(', ')}`);
}

function patchAttrs() {
  const { file, src } = load('template/validator.js');
  if (src.includes(MARK)) {
    console.log('patch-toolkit: component attributes already applied');
    return;
  }
  const edits = [];
  for (const [tag, names] of Object.entries(TAG_ATTRS)) {
    // The per-tag tables are plain object literals keyed by the tag name, each
    // holding its own `attrs:{}`.
    const tagAt = src.indexOf(`${tag}:{`);
    if (tagAt < 0) {
      console.error(`patch-toolkit: component \`${tag}\` not found in the table`);
      process.exit(1);
    }
    const attrsAt = src.indexOf('attrs:{', tagAt);
    if (attrsAt < 0) {
      console.error(`patch-toolkit: \`${tag}\` has no attrs table`);
      process.exit(1);
    }
    const head = attrsAt + 'attrs:{'.length;
    edits.push([head, names.map(n => `"${n}":{},`).join(''), tag, names]);
  }
  // Apply from the end so the earlier offsets stay valid, marker first.
  edits.sort((a, b) => b[0] - a[0]);
  let out = src;
  for (const [head, add] of edits) {
    out = out.slice(0, head) + MARK + add + out.slice(head);
  }
  fs.writeFileSync(file, out);
  console.log('patch-toolkit: added component attributes');
  for (const [, , tag, names] of edits) console.log(`  ${tag}: ${names.join(', ')}`);
}

patchStyles();
patchAttrs();
